const http = require('http');

function request(method, path, body) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify(body);
        const options = {
            hostname: 'localhost', port: 5000, path, method,
            headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }
        };
        const req = http.request(options, (res) => {
            let b = '';
            res.on('data', chunk => b += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(b) }));
        });
        req.on('error', reject);
        req.write(data);
        req.end();
    });
}

async function main() {
    console.log('--- Seeding Admin Account ---');
    const adminRes = await request('POST', '/api/auth/register', {
        name: 'NovaCart Admin', email: 'admin@novacart.com', password: 'Admin1234', role: 'admin'
    });
    if (adminRes.status === 400 && adminRes.body.message === 'Email already in use') {
        console.log('Admin already exists — OK');
    } else {
        console.log('Admin created:', adminRes.status, adminRes.body.name, '| role:', adminRes.body.role);
    }

    console.log('\n--- Seeding Customer Account ---');
    const userRes = await request('POST', '/api/auth/register', {
        name: 'John Customer', email: 'john@test.com', password: 'Pass1234'
    });
    if (userRes.status === 400 && userRes.body.message === 'Email already in use') {
        console.log('Customer already exists — OK');
    } else {
        console.log('Customer created:', userRes.status, userRes.body.name);
    }

    console.log('\n--- Login Admin ---');
    const loginRes = await request('POST', '/api/auth/login', {
        email: 'admin@novacart.com', password: 'Admin1234'
    });
    console.log('Admin login:', loginRes.status, '| role:', loginRes.body.role, '| token:', loginRes.body.token ? 'YES' : 'NO');
    console.log('\nAll done! You can now login at http://localhost:5173/admin/login');
}

main().catch(console.error);
